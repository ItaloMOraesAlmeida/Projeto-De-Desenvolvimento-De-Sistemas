$("#limpar").on("click", function() {
	$("#limpar").attr("disabled","disabled");
});

function Nova()
{
location.href="login.jsp";
}