package br.com.desktravel.adaptadores;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import sun.java2d.pipe.SpanShapeRenderer.Simple;

public class AdaptadorViagem {
	
	public boolean getPendente(String situacao){
		switch(situacao){
			case "pendente":
				return true;
			case "ativa":
				return false;
			case "negada":
				return false;
			case "concluida":
				return true;
		}
		
		return false;
	}
	
	public boolean getaprovacao(String situacao){
		switch(situacao){
			case "pendente":
				return false;
			case "ativa":
				return true;
			case "negada":
				return false;
			case "concluida":
				return true;
			default:
				return false;
		}
		
	}
	
	public Date dataSaida(String data){
		SimpleDateFormat dataF = new SimpleDateFormat("yyyy/dd/MM");
		Date dataT = null;
		try {
			dataT = dataF.parse(data);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dataT;
	}
}
