package br.com.desktravel.adaptadores;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;

import br.com.desktravel.model.Custo;

public class AdaptadorViagem {
	
	public static boolean getPendente(String situacao){
		switch(situacao){
			case "pendente":
				return true;
			case "ativa":
				return false;
			case "negada":
				return false;
			case "concluida":
				return true;
		}
		
		return false;
	}
	
	public static boolean getaprovacao(String situacao){
		switch(situacao){
			case "pendente":
				return false;
			case "ativa":
				return true;
			case "negada":
				return false;
			case "concluida":
				return true;
			default:
				return false;
		}
		
	}
	
	public static Date dataSaida(String data){
		SimpleDateFormat dataF = new SimpleDateFormat("yyyy-dd-MM");
		Date dataT = null;
		try {
			dataT = dataF.parse(data);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return dataT;
	}
	
	public static Date dataVolta(String data, int dias){
		SimpleDateFormat dataF = new SimpleDateFormat("yyyy-dd-MM");
		Date dataT = null;
		try {
			dataT = dataF.parse(data);
		} catch (ParseException e) {
			e.printStackTrace();
		}
		
		Calendar c = Calendar.getInstance();
		c.setTime(dataT);
		c.add(Calendar.DATE, dias);
		
		return c.getTime();
	}
	
	public static Custo custo(float alimentacao, float combustivel, float hospedagem, float outroV, String desc){
		Custo custo = new Custo();
		
		double ali = Fd(alimentacao);
		double com = Fd(combustivel);
		double hos = Fd(hospedagem);
		double ou = Fd(outroV);
		
		custo.setAlimentacao(ali);
		custo.setCombustivel(com);
		custo.setHospedagem(hos);
		custo.setOutrosGastos(ou);
		custo.setDescOG(desc);
		
		return custo;
	}
	
	public static double Fd(float valor){
		String aux = "" + valor;
		return Double.parseDouble(aux);
	}
	
	public static float valor(double valor){
		return (float) valor;
	}
	
	public static float total(double h, double c, double a, double o){
		return (float) (h + c + a + o);
	}
	
	public static String situacao(boolean aprovacao, boolean pendente){
		if(aprovacao == false && pendente == false){
			System.out.println("el");
			return "negada";
		}else if(aprovacao == true && pendente == true){
			return "concluida";
		}else if(aprovacao == false && pendente == true){
			return "pendente";
		}else if(aprovacao == true && pendente == false){
			return "ativa";
		}
		
		return "";
	}
	
	public static String data(Calendar c){
		Date date = c.getTime();
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-dd-MM");
		
		return fmt.format(date);
	}
}
