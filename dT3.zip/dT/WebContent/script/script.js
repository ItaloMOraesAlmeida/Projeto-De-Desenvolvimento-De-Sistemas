function butaoAprova(a) {
	document.getElementById("decis" + a).value = true;
}

function butaoNega(x) {
	document.getElementById("decis" + x).value = false;
}
