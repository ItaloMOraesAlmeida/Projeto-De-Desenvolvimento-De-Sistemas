package br.com.desktravel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

import br.com.desktravel.model.Trabalho;

public class ViagemTrabalhoDao {
	
	private Connection conexao;
	
	public ViagemTrabalhoDao(Connection conexao){
		this.conexao = conexao;
	}
	
	public void adiciona(ArrayList<Integer> idsT, int idV){
		String sql = "insert into viagem_trabalhos (id_viagem, id_trabalhos) values (?, ?);";
		
		try{
			PreparedStatement psmt = conexao.prepareStatement(sql);
			
			for (Integer i : idsT) {
				psmt.setInt(1, idV);
				psmt.setInt(2, i);
				
				psmt.execute();
			}
			
			psmt.close();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}

	public ArrayList<Trabalho> trabalhos(int idV){
		String sql = "select * from viagem_trabalhos where id_viagem = ?";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			
			pstm.setInt(1, idV);
			
			ResultSet rs = pstm.executeQuery();
			ArrayList<Trabalho> trabalhos = new ArrayList<Trabalho>();
			
			while (rs.next()) {
				int idT = rs.getInt("id_trabalhos");
				Trabalho trabalho = new TrabalhoDAO(this.conexao).trabalho(idT);
				
				trabalhos.add(trabalho);
			}
			
			rs.close();
			pstm.close();
			
			return trabalhos;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void deletaViagem(int id){
		String sql = "delete from viagem_trabalhos where id_viagem = ?;";
		
		try{
			PreparedStatement psmt = conexao.prepareStatement(sql);
			psmt.setInt(1, id);
			
			psmt.execute();
			
			psmt.close();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
