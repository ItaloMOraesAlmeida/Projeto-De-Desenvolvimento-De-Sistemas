package br.com.desktravel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import br.com.desktravel.model.Status;
import br.com.desktravel.model.Trabalho;

public class TrabalhoDAO {
	
	private Connection conexao;
	
	public TrabalhoDAO(Connection conexao){
		this.conexao = conexao;
	}
	
	public Trabalho trabalho(int id){
		String sql = "select * from trabalhos join trabalho on (idT = trabalho.id) and trabalhos.id = ?;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			
			pstm.setInt(1, id);
			
			ResultSet rs = pstm.executeQuery();
			Trabalho trabalho = null;
		
			while(rs.next()){
				String nome = rs.getString("nome");
				String descricao = rs.getString("descricao");
				String status = rs.getString("status");
				int idT = rs.getInt("idT");
				
				Status status2 = null;
				
				for(Status statu : Status.values()){
					
					if(statu.getValor().equals(status)){
						status2 = statu;
					}
					
				}
				
				trabalho = new Trabalho();
				trabalho.setId(id);
				trabalho.setNome(nome);
				trabalho.setDescricao(descricao);
				trabalho.setStatus(status2);
				trabalho.setIdT(idT);
			}
			
			rs.close();
			pstm.close();
			
			return trabalho;
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public int adiciona(Trabalho trabalho){
		String sql = "insert into trabalhos(idT, status) values (?, ?);";
		String sql2 = "SELECT @@IDENTITY AS 'Identity';";
		
		try{
			PreparedStatement pstmt = conexao.prepareStatement(sql);
			PreparedStatement pstmt1 = conexao.prepareStatement(sql2);
			
			pstmt.setInt(1, trabalho.getId());
			pstmt.setString(2, trabalho.getStatus().getValor());
			pstmt.execute();
			
			ResultSet rs = pstmt1.executeQuery();
			
			int id = 0;
			
			while(rs.next()){
				String idE = rs.getString("Identity");
				
				id = Integer.parseInt(idE);
				
			}
			
			rs.close();
			pstmt.close();
			
			
			return id;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void atualizaStatus(int id, Status statu){
		String sql = "update trabalhos set status = ? where id = ?;";
		try{
			PreparedStatement psmt = conexao.prepareStatement(sql);
			psmt.setString(1, statu.valor);
			psmt.setInt(2, id);
			
			psmt.execute();
			psmt.close();
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
