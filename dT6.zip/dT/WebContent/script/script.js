function butaoAprova(a) {
	document.getElementById("decis" + a).value = true;
}

function butaoNega(x) {
	document.getElementById("decis" + x).value = false;
}

//$("button[class='sum']").on("click", function(event) {
//	$("#trM").css({display: "block"});
//});
//$(".modal").blur(function() {
//	$("#trM").css({display: "none"});
//});
//$("button[class!='sum']").on("click", function() {
//	$("#trM").css({display: "none"});
//});
//
//$("input").on("click", function() {
//	$("#trM").css({display: "block"});
//});
