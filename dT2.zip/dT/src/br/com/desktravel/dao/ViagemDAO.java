package br.com.desktravel.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;

import br.com.desktravel.model.Custo;
import br.com.desktravel.model.Endereco;
import br.com.desktravel.model.Trabalho;
import br.com.desktravel.model.Usuario;
import br.com.desktravel.model.Viagem;

public class ViagemDAO {
	
	private Connection conexao;
	
	public ViagemDAO(Connection conexao){
		this.conexao = conexao;
	}
	
	public ArrayList<Viagem> viagemPendentesAdm(){
		String sql = "select  * from viagem join usuario on viagem.usuario_id = usuario.id and viagem.pendente = true and viagem.aprovacao = false;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			
			ResultSet rs = pstm.executeQuery();
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				String aprovacao = rs.getString("aprovacao");
				int idC = rs.getInt("custo_id");
				int idE = rs.getInt("endereco_id");
				String pendente = rs.getString("pendente");
				
				Boolean aprov = Boolean.parseBoolean(aprovacao);
				Boolean pend = Boolean.parseBoolean(pendente);
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				Calendar cV = Calendar.getInstance();
				cS.setTime(dataSaida);
				cV.setTime(dataVolta);
				
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			rs.close();
			pstm.close();
			
			return viagens;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	//superior
	public ArrayList<Viagem> viagemPendentes(Usuario usuario){
		String sql = "select  * from viagem join usuario on viagem.usuario_id = usuario.id and usuario.id_superior = ? and viagem.pendente = true and viagem.aprovacao = false;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, usuario.getId());
			
			ResultSet rs = pstm.executeQuery();
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				String aprovacao = rs.getString("aprovacao");
				int idC = rs.getInt("custo_id");
				int idE = rs.getInt("endereco_id");
				String pendente = rs.getString("pendente");
				
				Boolean aprov = Boolean.parseBoolean(aprovacao);
				Boolean pend = Boolean.parseBoolean(pendente);
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				Calendar cV = Calendar.getInstance();
				cS.setTime(dataSaida);
				cV.setTime(dataVolta);
				
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			rs.close();
			pstm.close();
			
			return viagens;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	//Propria
	public ArrayList<Viagem> viagemPendentesP(Usuario usuario){
		String sql = "select  * from viagem where usuario_id = ? and aprovacao = false and pendente = true;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, usuario.getId());
			
			ResultSet rs = pstm.executeQuery();
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				String aprovacao = rs.getString("aprovacao");
				int idC = rs.getInt("custo_id");
				int idE = rs.getInt("endereco_id");
				String pendente = rs.getString("pendente");
				
				Boolean aprov = Boolean.parseBoolean(aprovacao);
				Boolean pend = Boolean.parseBoolean(pendente);
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				Calendar cV = Calendar.getInstance();
				cS.setTime(dataSaida);
				cV.setTime(dataVolta);
				
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			rs.close();
			pstm.close();
			
			return viagens;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void adiciona(Viagem viagem){
		
		String sql = "insert into viagem(usuario_id, duracao, custo_id, endereco_id, aprovacao, pendente, dataSaida, dataVolta) values (?, ?, ?, ?, ?, ?, ?, ?);";

		String sql2 = "SELECT @@IDENTITY AS 'Identity';";

		CustoDAO daoC = new CustoDAO(conexao);
		EnderecoDAO daoE = new EnderecoDAO(conexao);
		TrabalhoDAO daoT = new TrabalhoDAO(conexao);

		int idC = daoC.adiciona(viagem.getCusto()); 

		int idE = daoE.adiciona(viagem.getEndereco());

		ArrayList<Integer> idsT = new ArrayList<Integer>();

		for(Trabalho trab : viagem.getTrabalhos()){
			
			idsT.add(daoT.adiciona(trab));
		}
		
		try{
			PreparedStatement pstmt = conexao.prepareStatement(sql);
			PreparedStatement pstmt1 = conexao.prepareStatement(sql2);
			
			java.sql.Date datS = new java.sql.Date(viagem.getDataSaida().getTimeInMillis());
			java.sql.Date datV = new java.sql.Date(viagem.getDataVolta().getTimeInMillis());
			
			pstmt.setInt(1, viagem.getUsuario().getId());
			pstmt.setInt(2, viagem.getDuracao());
			pstmt.setInt(3, idC);
			pstmt.setInt(4, idE);
			pstmt.setBoolean(5, viagem.getAprovacao());
			pstmt.setBoolean(6, viagem.getPendente());
			pstmt.setDate(7, datS);
			pstmt.setDate(8, datV);
			
			pstmt.execute();
			
			ResultSet rs = pstmt1.executeQuery();
			
			int idV = 0;
			while(rs.next()){
				String idSv = rs.getString("Identity");
				
				idV = Integer.parseInt(idSv);
				
			}
			
			pstmt.close();
			new ViagemTrabalhoDao(this.conexao).adiciona(idsT, idV);
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void aprovacao(Viagem viagem){
		String sql = "update viagem set aprovacao = ? , pendente = false where viagem.id = ?;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setBoolean(1, viagem.getAprovacao());
			pstm.setInt(2, viagem.getId());
			
			pstm.execute();
			
			pstm.close();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ArrayList<Viagem> ativaAdm(){
		
		String sql = "select  * from viagem join usuario on viagem.usuario_id = usuario.id and viagem.aprovacao = true and viagem.pendente = false;";
		
		try{
			
			PreparedStatement pstm = conexao.prepareStatement(sql);
			
			ResultSet rs = pstm.executeQuery();
			
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR= new CustoDAO(conexao).custo(idCR);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);		
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			return viagens;
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ArrayList<Viagem> ativa(int idS){
		
		String sql = "select  * from viagem join usuario on (viagem.usuario_id = usuario.id and usuario.id_superior = ?) and viagem.aprovacao = true and viagem.pendente = false;";
		
		try{
			
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, idS);
			
			ResultSet rs = pstm.executeQuery();
			
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR= new CustoDAO(conexao).custo(idCR);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);		
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			return viagens;
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
public ArrayList<Viagem> concluidaAdm(){
		
		String sql = "select  * from viagem join usuario on viagem.usuario_id = usuario.id and viagem.aprovacao = true and viagem.pendente = true;";
		
		try{
			
			PreparedStatement pstm = conexao.prepareStatement(sql);
			
			ResultSet rs = pstm.executeQuery();
			
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR= new CustoDAO(conexao).custo(idCR);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);		
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			return viagens;
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ArrayList<Viagem> concluida(int idS){
		
		String sql = "select  * from viagem join usuario on (viagem.usuario_id = usuario.id and usuario.id_superior = ?) and viagem.aprovacao = true and viagem.pendente = true;";
		
		try{
			
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, idS);
			
			ResultSet rs = pstm.executeQuery();
			
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR= new CustoDAO(conexao).custo(idCR);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);		
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			return viagens;
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ArrayList<Viagem> viagensUsuario(int idU){
		
		String sql = "select * from viagem where usuario_id = ?;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, idU);
			
			ResultSet rs = pstm.executeQuery();
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int duraca = rs.getInt("duracao");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				
				
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			return viagens;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void remove(int id){
		
		String sql="delete from viagem where id = ?;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, id);
			
			pstm.execute();
			
			pstm.close();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Viagem viagem(int id){
		String sql = "select * from viagem where id = ?;";
		
		try{
			PreparedStatement psmst = conexao.prepareStatement(sql);
			psmst.setInt(1, id);
			
			ResultSet rs = psmst.executeQuery();
			Viagem viagem = null;
			
			while(rs.next()){
				viagem = new Viagem();
				
				int duraca = rs.getInt("duracao");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
	
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR= new CustoDAO(this.conexao).custo(idCR);

				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
			}
			
			return viagem;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Viagem viagemAtivaU(int idU){
		String sql = "select * from viagem where usuario_id = ? and aprovacao = true and pendente = false;";
		
		try{
			PreparedStatement psmst = conexao.prepareStatement(sql);
			psmst.setInt(1, idU);
			
			ResultSet rs = psmst.executeQuery();
			Viagem viagem = null;
			
			while(rs.next()){
				viagem = new Viagem();
				
				int id = rs.getInt("id");
				int duraca = rs.getInt("duracao");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
			}
			
			return viagem;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void viagemConclui(int id){
		String sql = "update viagem set aprovacao = true, pendente = true where id = ?; ";
		try{
			PreparedStatement psmt = conexao.prepareStatement(sql);
			psmt.setInt(1, id);
			
			psmt.execute();
			psmt.close();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ArrayList<Viagem> viagensExist(int idU){
		
		String sql = "select * from viagem where (usuario_id = ? and aprovacao = true and pendente = false ) or (usuario_id = ? and aprovacao = false and pendente = true );";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, idU);
			pstm.setInt(2, idU);
			
			ResultSet rs = pstm.executeQuery();
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int duraca = rs.getInt("duracao");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				
				
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				viagens.add(viagem);
			}
			
			return viagens;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public Viagem viagemAtivaGasto(int idU){
		String sql = "select * from viagem where usuario_id = ? and aprovacao = true and pendente = false;";
		
		try{
			PreparedStatement psmst = conexao.prepareStatement(sql);
			psmst.setInt(1, idU);
			
			ResultSet rs = psmst.executeQuery();
			Viagem viagem = null;
			
			while(rs.next()){
				viagem = new Viagem();
				
				int id = rs.getInt("id");
				int duraca = rs.getInt("duracao");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR = new CustoDAO(this.conexao).custo(idCR);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
			}
			
			return viagem;
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public void addCustoNovo(int idV, int idC){
		String sql="update viagem set custoR_id = ? where id = ?;";
		
		try{
			PreparedStatement pstm = conexao.prepareStatement(sql);
			pstm.setInt(1, idC);
			pstm.setInt(2, idV);
			
			pstm.execute();
			
			pstm.close();
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
	
	public ArrayList<Viagem> viagensMes(int mes, int idS){
		String sql = "select  * from viagem join usuario on (viagem.usuario_id = usuario.id) and viagem.aprovacao = true and viagem.pendente = true;";
		
		try{
			
			PreparedStatement pstm = conexao.prepareStatement(sql);
			
			ResultSet rs = pstm.executeQuery();
			
			ArrayList<Viagem> viagens = new ArrayList<Viagem>();
			
			while(rs.next()){
				
				int id = rs.getInt("id");
				int idU = rs.getInt("usuario_id");
				Date dataSaida = rs.getDate("dataSaida");
				Date dataVolta = rs.getDate("dataVolta");
				int duraca = rs.getInt("duracao");
				Boolean aprov = rs.getBoolean("aprovacao");
				int idC = rs.getInt("custo_id");
				int idCR = rs.getInt("custoR_id");
				int idE = rs.getInt("endereco_id");
				Boolean pend = rs.getBoolean("pendente");
				
				Usuario u = new Usuario();
				u = new UsuarioDAO(this.conexao).usuario(idU);
				
				Custo c = new Custo();
				c = new CustoDAO(this.conexao).custo(idC);
				
				Custo cR = new Custo();
				cR= new CustoDAO(conexao).custo(idCR);
				
				Endereco e = new Endereco();
				e = new EnderecoDAO(this.conexao).endereco(idE);		
				
				Calendar cS = Calendar.getInstance();
				cS.setTime(dataSaida);
				Calendar cV = Calendar.getInstance();
				cV.setTime(dataVolta);
				Viagem viagem = new Viagem();
				viagem.setId(id);
				viagem.setAprovacao(aprov);
				viagem.setCusto(c);
				viagem.setCustoR(cR);
				viagem.setEndereco(e);
				viagem.setTrabalhos(new ViagemTrabalhoDao(this.conexao).trabalhos(id));
				viagem.setUsuario(u);
				viagem.setDataSaida(cS);
				viagem.setDataVolta(cV);
				viagem.setDuracao(duraca);
				viagem.setPendente(pend);
				
				if((cS.get(Calendar.MONTH) + 1) == mes){
					viagens.add(viagem);
				}
			}
			
			return viagens;
			
		}catch (SQLException e) {
			throw new RuntimeException(e);
		}
	}
}
