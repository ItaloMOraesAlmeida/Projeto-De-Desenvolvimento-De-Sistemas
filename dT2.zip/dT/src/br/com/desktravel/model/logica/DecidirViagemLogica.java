package br.com.desktravel.model.logica;

import java.sql.Connection;
import java.util.ArrayList;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import br.com.desktravel.dao.CustoDAO;
import br.com.desktravel.dao.TrabalhoDAO;
import br.com.desktravel.dao.ViagemDAO;
import br.com.desktravel.model.Custo;
import br.com.desktravel.model.Status;
import br.com.desktravel.model.Trabalho;
import br.com.desktravel.model.Viagem;

public class DecidirViagemLogica implements Logica{

	@Override
	public void executa(HttpServletRequest httpServletRequest, HttpServletResponse httpServletResponse)
			throws Exception {
		Connection conexao = (Connection)httpServletRequest.getAttribute("conexao");
		
		String idViagemString = httpServletRequest.getParameter("idViagem");
		String aprovacao = httpServletRequest.getParameter("decisao");
		
		int idViagem = Integer.parseInt(idViagemString);
		Boolean aprovacaoViagem = Boolean.parseBoolean(aprovacao);
		
		ViagemDAO dao = new ViagemDAO(conexao);
		Viagem viagem = dao.viagem(idViagem);
		viagem.setAprovacao(aprovacaoViagem);
		viagem.setTrabalhos(alterarStatus(aprovacaoViagem, viagem.getTrabalhos()));
		atualizarTrabalhos(viagem.getTrabalhos(), conexao);
		
		dao.aprovacao(viagem);
		
		if(viagem.getAprovacao() == true){
			CustoDAO daoC = new CustoDAO(conexao);
			int idC = daoC.adiciona(viagem.getCusto());
			dao.addCustoNovo(viagem.getId(), idC);
		}
		
		new ConsultaViagemPendentesLogica().executa(httpServletRequest, httpServletResponse);
	}
	
	public ArrayList<Trabalho> alterarStatus(boolean aprovacao, ArrayList<Trabalho> trabalhos){
		
		if(aprovacao == true){
			for(Trabalho t : trabalhos){
				t.setStatus(Status.emProgresso);
			}
		}else{
			for(Trabalho t : trabalhos){
				t.setStatus(Status.negado);
			}
		}
		
		return trabalhos;
	}
	
	public void atualizarTrabalhos(ArrayList<Trabalho> trabalhos, Connection conexao){
		TrabalhoDAO dao = new TrabalhoDAO(conexao);
		
		for(Trabalho t : trabalhos){
			dao.atualizaStatus(t.getId(), t.getStatus());
		}
	}
}
